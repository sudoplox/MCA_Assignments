In order to run the code, please follow the instruction below:


1) download the required Python packages: 
- nltk: http://www.nltk.org/install.html
- sklearn: http://scikit-learn.org/stable/install.html

2) Boilrplate code is provided in directory Problem_2

3) run the python file 'main.py' 

Please, write your code in the file 'relevance_feedback.py'


For any question, please write to mohits@iiitd.ac.in or hitkuli@iiitd.ac.in.
